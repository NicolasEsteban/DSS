package modelos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class PredioModel {
    public void insertar_predio(ArrayList<String> celdas,int aux){
        String sql = "INSERT INTO PREDIO (tecnico,productor,super_men,nombre_predio,comuna_predio,km_talca,productividad) VALUES(?,?,?,?,?,?,?)";
        
        Conexion con = new Conexion();
        PreparedStatement ps;
        Connection conn = con.getConexion();
        
        
        try { 
            ps = conn.prepareStatement(sql);
            ps.setString(1,celdas.get(0+aux));
            ps.setString(2,celdas.get(1+aux));
            ps.setString(3,celdas.get(2+aux));
            ps.setString(4,celdas.get(3+aux));
            ps.setString(5,celdas.get(4+aux));
            ps.setInt(6, Integer.parseInt(celdas.get(5+aux)));
            ps.setString(7,"");
            ps.execute();
            
        } catch (SQLException ex) {
            Logger.getLogger(PredioModel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ArrayList llamar_predios(){ // funcion que llama la lista de predios en la vista de planificacion
        Conexion con = new Conexion();
        PreparedStatement ps;
        ResultSet rs;
        Connection conn = con.getConexion();
        ArrayList<PredioSeleccionado> Listapredios = new ArrayList();
        
        try {
            ps = conn.prepareStatement("SELECT nombre_predio,super_men FROM PREDIO");
            rs = ps.executeQuery();
            
            while (rs.next()){ // se guardan los datos en un arreglo de tipo objeto 
                //Listapredios.add(rs.getString(1));
                PredioSeleccionado Psel = new PredioSeleccionado(rs.getString(1),rs.getString(2));
                Listapredios.add(Psel);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PredioModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return Listapredios;        
    }
    
    public int llamar_predio_seleccionado(String super_men,String nombre_predio){ // obtiene el km a partir de dos atributos
        Conexion con = new Conexion();
        PreparedStatement ps;
        ResultSet rs;
        Connection conn = con.getConexion();
        String sql= "SELECT km_talca FROM PREDIO WHERE super_men=? AND nombre_predio=?;";

        int km_talca=0;
        
        try {
            ps = conn.prepareStatement(sql);
            ps.setString(1, super_men);
            ps.setString(2, nombre_predio);
            rs = ps.executeQuery();
            while (rs.next()){  
                km_talca=rs.getInt("km_talca");               
            }
            
            //System.out.println(km_talca);//se imprime km
            
            
            
        } catch (SQLException ex) {
            Logger.getLogger(PredioModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return km_talca;
    }
    
    /*public  Predio llamar_predio_seleccionado(int id,int numC){
        Predio pr = new Predio();
        Conexion con = new Conexion();
        PreparedStatement ps;
        ResultSet rs;
        Connection conn = con.getConexion();
        String sql= "SELECT super_men,km_talca FROM PREDIO WHERE id=?;";
        String super_men=null;
        int km_talca=0;
        
        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(1,id);
            rs = ps.executeQuery();
            while (rs.next()){  
                super_men=rs.getString("super_men");
                km_talca=rs.getInt("km_talca");               
            }
            String[] parts = super_men.split(","); //se separa las partes usando la coma
            String part1 = parts[0]; 
            String part2 = parts[1];
            int velocidad=50;
           
            float tiempo= (float)km_talca/velocidad*60;
            float tiempoC = (float)10/numC*60;
            
            
            pr= new Predio(id,numC,tiempoC,tiempo);
            
        } catch (SQLException ex) {
            Logger.getLogger(PredioModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pr;
    }*/
}
