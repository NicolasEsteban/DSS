/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import modelos.*;

public class Ventana_agregar_cargas extends javax.swing.JDialog {
    int posicion=0,Ncargas[],contador=0;
    ArrayList<PredioSeleccionado> listaSelec = new ArrayList();
    
    public Ventana_agregar_cargas(java.awt.Frame parent, boolean modal,ArrayList<PredioSeleccionado> seleccionados) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(null);
        Ncargas=new int[seleccionados.size()];
        contador= seleccionados.size();
        for(int i=0;i<seleccionados.size();i++){ // se pasan datos del arraylist al arraylist global
            listaSelec.add(seleccionados.get(i));
        }
        
        for(int i=0;i<seleccionados.size();i++){// se inicializa vector de cargas
            Ncargas[i]=-1;
        }
        
        // se desabilitan campos de textos
        /*jpredios.setEditable(false);
        jpredios.setText(seleccionados.get(posicion).getNombre_predio());
        
        
        jcargas.setHorizontalAlignment(JTextField.CENTER); 
        
        jcontador.setEditable(false);
        jcontador.setText(String.valueOf(seleccionados.size()));
        jcontador.setHorizontalAlignment(JTextField.CENTER); 
        */
        
        //PredioModel pm = new PredioModel();
        //pm.llamar_predio_seleccionado(seleccionados.get(posicion).getSuper_men(),seleccionados.get(posicion).getNombre_predio());
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jcontador = new javax.swing.JTextField();
        jcargas = new javax.swing.JTextField();
        jpredios = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jcontador.setBackground(new java.awt.Color(255, 255, 255));
        jcontador.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jcontador.setForeground(new java.awt.Color(0, 0, 0));
        getContentPane().add(jcontador, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 240, 70, 40));

        jcargas.setBackground(new java.awt.Color(255, 255, 255));
        jcargas.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jcargas.setForeground(new java.awt.Color(0, 0, 0));
        jcargas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jcargasKeyTyped(evt);
            }
        });
        getContentPane().add(jcargas, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 180, 70, 40));

        jpredios.setBackground(new java.awt.Color(255, 255, 255));
        jpredios.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jpredios.setForeground(new java.awt.Color(0, 0, 0));
        jpredios.setCaretColor(new java.awt.Color(0, 0, 0));
        getContentPane().add(jpredios, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 130, 280, 40));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Ingresar cantidad de cargas por predio");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 240, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo blanco.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 60, 350, 50));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Cancelar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 320, 90, 50));

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setForeground(new java.awt.Color(0, 0, 0));
        jButton2.setText("Ingresar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 180, 110, 40));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 0));
        jLabel8.setText("Predios");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 260, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 0));
        jLabel6.setText("Cargas:");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, -1, 20));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 0));
        jLabel7.setText("Quedan");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 260, -1, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setText("Predio: ");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, -1, 30));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo plomo.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 110, 350, 190));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/tomates.jpg"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        /*int km_talca=0;
        ArrayList<Predio> entradaGrasp = new ArrayList();
        if(jcargas.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Ingresar valor en el campo de texto");
        }else{
            if(contador>1){
                
                Ncargas[posicion]=Integer.parseInt(jcargas.getText()); // se almacena carga en la posicion indicada
                posicion++; // se procede a mostrar el siguiente elemento
                jpredios.setText(listaSelec.get(posicion).getNombre_predio());
                
                
                contador--; // contador decrece y se muestra en la intefaz
                jcontador.setText(String.valueOf(contador));
                jcargas.setText("");// se limpia el campo de texto
                
            }else{
                
                Ncargas[posicion]=Integer.parseInt(jcargas.getText()); // se ingresa las cargas del ultimo predio
                
                JOptionPane.showMessageDialog(null,"Cargas ingresadas correctamente"); // mensjae 
                
                
                jcargas.setText("");
                jcargas.setEnabled(false);// se bloquea el campo de texto cuando termina de ocuparce
                
                PredioModel pm = new PredioModel();
                for(int i=0;i<listaSelec.size();i++){// se extrae la distancia del predio con respecto a talca
                    km_talca=pm.llamar_predio_seleccionado(listaSelec.get(i).getSuper_men(),listaSelec.get(i).getNombre_predio());
                    Predio pr;
                    float tiempo= (float)km_talca/50*60; // se multiplican por 60 para que se midan en minutos
                    float tiempoC = (float)10/Ncargas[i]*60;
                    
                    pr=new Predio(listaSelec.get(i).getLugar(),Ncargas[i],tiempoC,tiempo);
                    entradaGrasp.add(pr);
                }
                
                ventana_ejecucion_grasp dialog = new ventana_ejecucion_grasp(new javax.swing.JFrame(), true,entradaGrasp,listaSelec);// se llama ventana para ejecutar algoritmo
                dialog.setVisible(true);
                dispose(); // se cierra al cerrar la ventana siguiente
            }
            
            
        }*/
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jcargasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jcargasKeyTyped
        char car= evt.getKeyChar();// para restringir solo el paso de numeros enteros
        if((car<'0' || car>'9') && (car!=',' || car!='.')) evt.consume();
    }//GEN-LAST:event_jcargasKeyTyped

    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JTextField jcargas;
    private javax.swing.JTextField jcontador;
    private javax.swing.JTextField jpredios;
    // End of variables declaration//GEN-END:variables
}
