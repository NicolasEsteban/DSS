
package modelos;

import java.io.File;
import java.sql.Connection;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.impl.common.IOUtil;
import static ventanas.ventana_ejecucion_grasp.calcularHora;
import static ventanas.ventana_salida_grasp.buscarBloque;






public class ModeloExcel {
   
   public void reporte(){
       // se crea libro en excel
        Workbook book = new XSSFWorkbook();
        Sheet sheet = book.createSheet("ZONA SUR");
        try {
            
            
            
            CellStyle headerStyle = book.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
            
            // estilo para titulo 
            CellStyle tituloEstilo = book.createCellStyle();
            tituloEstilo.setAlignment(HorizontalAlignment.CENTER);
            tituloEstilo.setVerticalAlignment(VerticalAlignment.CENTER);
            Font fuenteTitulo = book.createFont();
            fuenteTitulo.setFontName("Arial");
            fuenteTitulo.setBold(true);
            fuenteTitulo.setFontHeightInPoints((short) 14);
            tituloEstilo.setFont(fuenteTitulo);

            Row filaTitulo = sheet.createRow(1);
            Cell celdaTitulo = filaTitulo.createCell(1);
            celdaTitulo.setCellStyle(tituloEstilo);
            celdaTitulo.setCellValue("Informacion de los predios en detalle");
            
            // se crean estilos para los encabezados en el reporte
            headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            headerStyle.setBorderLeft(BorderStyle.THIN);
            headerStyle.setBorderRight(BorderStyle.THIN);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            
            Font font = book.createFont();
            font.setFontName("Arial");
            font.setBold(true);
            font.setColor(IndexedColors.WHITE.getIndex());
            font.setFontHeightInPoints((short) 12);
            headerStyle.setFont(font);
            
            
            
            
            String[] cabecera = new String[]{"Tecnico", "Productor", "Super men", "Nombre del Predio", "Comuna donde pretenece el predio","Distancia con talca en KM"};
            Row filaEncabezados = sheet.createRow(3);
            
           
            for (int i = 0; i < cabecera.length; i++) {// imprime encabezado en excel
                
                Cell celdaEnzabezado = filaEncabezados.createCell(i);
                celdaEnzabezado.setCellStyle(headerStyle);
                celdaEnzabezado.setCellValue(cabecera[i]);
                
                
            }
            
            Conexion con = new Conexion();
            PreparedStatement ps;
            ResultSet rs;
            Connection conn = con.getConexion();
            
            int numFilaDatos = 4;
            
            ps = conn.prepareStatement("SELECT tecnico,productor,super_men,nombre_predio,comuna_predio,km_talca cantidad FROM PREDIO");
            rs = ps.executeQuery();
            
            CellStyle prueba = book.createCellStyle();
            prueba.setAlignment(HorizontalAlignment.CENTER);
            prueba.setVerticalAlignment(VerticalAlignment.CENTER);
            
            int numCol = rs.getMetaData().getColumnCount(); // se calcula la cantidad de variables que trae la consulta
            while (rs.next()){ // 
                
                Row fila_datos= sheet.createRow(numFilaDatos); // se crea la fila que se usara
                for (int i = 1; i <= numCol; i++) {// se van registrando los datos en el archivo
                Cell celdadatos = fila_datos.createCell(i-1); 
                celdadatos.setCellStyle(prueba);
                celdadatos.setCellValue(rs.getString(i));
                sheet.autoSizeColumn(i-1); // se van ajustando las columnas 
                
                }
                
                numFilaDatos++;
                
                               
            }
            
            
            
            FileOutputStream fileOut = new FileOutputStream("C:\\Users\\Nicolas\\Desktop\\Lista de predios almacenados.xlsx");
            book.write(fileOut);
            fileOut.close();
            JOptionPane.showMessageDialog(null,"Lista de predios almacenados.xlsx se descargo con exito en su escritorio");
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ModeloExcel.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(ModeloExcel.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ModeloExcel.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
   
   public void leer(File archivo) throws IOException {
        //FileInputStream file = new FileInputStream(new File("C:\\Users\\Nicolas\\Desktop\\DISTANCIAS PREDIOS TEMP 15-16.xlsx"));
        ArrayList<String> celdas = new ArrayList<String>();
        try {
            //String rutaArchivoExcel = "C:/Users/Nicolas/Desktop/DISTANCIAS PREDIOS TEMP 15-16.xlsx";
            FileInputStream inputStream = new FileInputStream(archivo);
            Workbook workbook = new XSSFWorkbook(inputStream);
            Sheet firstSheet = workbook.getSheetAt(0);
            Iterator iterator = firstSheet.iterator();
            
            DataFormatter formatter = new DataFormatter();
            int verificador=0; // para verificar si la fila tiene una determinada columna
            
            /*Conexion con = new Conexion();
            PreparedStatement ps;
            ResultSet rs;
            Connection conn = con.getConexion();*/
            
            while (iterator.hasNext()) { // se leen filas
                Row nextRow = (Row) iterator.next();
                Iterator cellIterator = nextRow.cellIterator();
                //System.out.println("\n");
                int j=0;
                while(cellIterator.hasNext()) { // se leen columnas
                    Cell cell = (Cell) cellIterator.next();
                    String contenidoCelda = formatter.formatCellValue(cell);
                    if(verificador==1){
                        celdas.add(contenidoCelda);
                    }
                    j++;
                }
                if(j==6){ // si en la fila hay 6 columnas el verificador cambia de valor
                    verificador=1;
                }                                
            }
            
            int filas= celdas.size()/6,aux=0;
            PredioModel in = new PredioModel();
            for(int i=0;i<filas;i++){
               in.insertar_predio(celdas,aux);              
               aux=aux+6;
                
            }
            
                
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
   
   public void salida_grasp(ArrayList<Predio> predios,ArrayList<Bloque> bloques,ArrayList<PredioSeleccionado> nombresPredios){
       
        Workbook book = new XSSFWorkbook();
        Sheet sheet = book.createSheet("PLANIFICACION ZONA SUR");
        
        SimpleDateFormat formateador = new SimpleDateFormat("dd-MM-yyyy"); 
        Date date = new Date();
        //System.out.println(formateador.format(date));
        try {
            CellStyle headerStyle = book.createCellStyle();
            headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
            
            // estilos para el titulo
            CellStyle tituloEstilo = book.createCellStyle();
            tituloEstilo.setAlignment(HorizontalAlignment.CENTER);
            tituloEstilo.setVerticalAlignment(VerticalAlignment.CENTER);
            Font fuenteTitulo = book.createFont();
            fuenteTitulo.setFontName("Arial");
            fuenteTitulo.setBold(true);
            fuenteTitulo.setFontHeightInPoints((short) 14);
            tituloEstilo.setFont(fuenteTitulo);
            
            // se describe la ubicacion del titulo y la descripcion
            Row filaTitulo = sheet.createRow(0);
            Cell celdaTitulo = filaTitulo.createCell(0);
            celdaTitulo.setCellStyle(tituloEstilo);           
            celdaTitulo.setCellValue("Resultado planificacion zona sur");
            sheet.addMergedRegion(new CellRangeAddress(0,1,0,4));
            
           
            
            // se crean estilos para los encabezados en el reporte
            headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex());
            headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            headerStyle.setBorderLeft(BorderStyle.THIN);
            headerStyle.setBorderRight(BorderStyle.THIN);
            headerStyle.setBorderBottom(BorderStyle.THIN);
            
            Font font = book.createFont();
            font.setFontName("Arial");
            font.setBold(true);
            font.setColor(IndexedColors.WHITE.getIndex());
            font.setFontHeightInPoints((short) 12);
            headerStyle.setFont(font);
            
            
            String[] cabeceraBloque = new String[]{"Bloques", "Tiempo de inicio del bloque"};
            
            Row filaEncabezadosBloque = sheet.createRow(3);
            
            for (int i = 0; i < cabeceraBloque.length; i++) {// imprime encabezado en excel
                
                Cell celdaEnzabezado = filaEncabezadosBloque.createCell(i);
                celdaEnzabezado.setCellStyle(headerStyle);
                celdaEnzabezado.setCellValue(cabeceraBloque[i]);
                sheet.autoSizeColumn(i); 
                
            }
            // estilos para el contenido 
            CellStyle prueba = book.createCellStyle();
            prueba.setAlignment(HorizontalAlignment.CENTER);
            prueba.setVerticalAlignment(VerticalAlignment.CENTER);
            
            
            
            CellStyle negrita = book.createCellStyle();
            Font fontNegrita = book.createFont();//Create font 
            fontNegrita.setBoldweight(Font.BOLDWEIGHT_BOLD);
            negrita.setFont(fontNegrita);
            //negrita.setFillBackgroundColor(IndexedColors.DARK_BLUE.getIndex());
            negrita.setAlignment(HorizontalAlignment.CENTER);
            negrita.setVerticalAlignment(VerticalAlignment.CENTER);
            
            int filaBloques=4,numBloque=1;
            for (Bloque b : bloques) { // se imprime en excel bloques con sus horarios
                Row fila_bloques= sheet.createRow(filaBloques);
                Cell celdadatos = fila_bloques.createCell(0); 
                celdadatos.setCellStyle(prueba);
                
                celdadatos.setCellValue("Bloque "+numBloque);
                
                Cell celdadatos2 = fila_bloques.createCell(1);
                celdadatos2.setCellStyle(prueba);
                celdadatos2.setCellValue(calcularHora(b.a));
                filaBloques++;
                numBloque++;
            }
            //Se creara cabecera de la tabla de planificacion
            Row filaEncabezadosPlanificacion = sheet.createRow(28);
            String[] cabeceraPlanificacion = new String[25];
            cabeceraPlanificacion[0]="Predios";
            
            for(int i=1;i<25;i++){
                cabeceraPlanificacion[i]="Bloque "+i;
            }
            // cabezera de la tabla que mostrara la planificacion
            for (int i = 0; i < cabeceraPlanificacion.length; i++) {// imprime encabezado en excel para la tabla de planificacion
                
                Cell celdaEnzabezado = filaEncabezadosPlanificacion.createCell(i);
                celdaEnzabezado.setCellStyle(headerStyle);
                celdaEnzabezado.setCellValue(cabeceraPlanificacion[i]);
                sheet.autoSizeColumn(i); 
                
            }
            int filaDatosPlanificacion=29;
            // se imprimen datos mostrando la planificacion
            for(int i=0;i<predios.size();i++){
                int j=0;
                Row fila_planificacion= sheet.createRow(filaDatosPlanificacion);
                Cell celdadatos = fila_planificacion.createCell(j); 
                celdadatos.setCellStyle(prueba);
                celdadatos.setCellValue(nombresPredios.get(i).getNombre_predio()); // se coloca en una celda el nombre del predio
                sheet.autoSizeColumn(j);
                for (Carga c : predios.get(i).C) {
                    String[] parts = calcularHora(c.x).split(":");
                    String bloqueSeleccionado=parts[0]+":00:00"; // Se obtiene su tiempo de inicio
                    j=buscarBloque(bloques,bloqueSeleccionado); // se obtiene numero de celda en donde va el horario
                    
                    celdadatos = fila_planificacion.createCell(j); 
                    celdadatos.setCellStyle(prueba);
                    celdadatos.setCellValue(calcularHora(c.x)); // se escribe el horario en su respectiva celda  
                    sheet.autoSizeColumn(j);                    // se ajusta la columna
                    
                }
                
                filaDatosPlanificacion++;
            }
            filaDatosPlanificacion++;
            String resultadoBloque [] = {"CAPACIDAD FALTANTE","CAPACIDAD SOBRANTE","CAPACIDAD DE DESCARGA"};
            // ingresando el resto de los datos del bloque
            
            Row fila_capacidad_faltante= sheet.createRow(filaDatosPlanificacion);
            Cell celdadatos_faltante = fila_capacidad_faltante.createCell(0); 
            celdadatos_faltante.setCellStyle(negrita);
            celdadatos_faltante.setCellValue(resultadoBloque[0]);               
            filaDatosPlanificacion++;
            
            int capF=1,capS=1,capLl=1;
            for (Bloque b : bloques) {// imprime capacidad faltante en excel
                
                celdadatos_faltante = fila_capacidad_faltante.createCell(capF); 
                celdadatos_faltante.setCellStyle(prueba);
                celdadatos_faltante.setCellValue(b.CF);               
                capF++;
            }
            
            Row fila_capacidad_sobrante= sheet.createRow(filaDatosPlanificacion);
            Cell celdadatos_sobrante = fila_capacidad_sobrante.createCell(0); 
            celdadatos_sobrante.setCellStyle(negrita);
            celdadatos_sobrante.setCellValue(resultadoBloque[1]);               
            filaDatosPlanificacion++;
            
            for (Bloque b : bloques) {// imprime capacidad sobrante en excel
                
                celdadatos_sobrante = fila_capacidad_sobrante.createCell(capS); 
                celdadatos_sobrante.setCellStyle(prueba);
                celdadatos_sobrante.setCellValue(b.CS);               
                capS++;
            }
            
            Row fila_llegadas= sheet.createRow(filaDatosPlanificacion);
            Cell celdadatos_llegadas = fila_llegadas.createCell(0); 
            celdadatos_llegadas.setCellStyle(negrita);
            celdadatos_llegadas.setCellValue(resultadoBloque[2]);               
            filaDatosPlanificacion++;
            
            for (Bloque b : bloques) {// imprime capacidad de carga en cada bloque
                
                celdadatos_llegadas = fila_llegadas.createCell(capLl); 
                celdadatos_llegadas.setCellStyle(prueba);
                celdadatos_llegadas.setCellValue(b.N);               
                capLl++;
            }
            
            FileOutputStream fileOut;
            fileOut = new FileOutputStream("C:\\Users\\Nicolas\\Desktop\\Planificacion "+formateador.format(date)+".xlsx");
            book.write(fileOut);
            fileOut.close();
            JOptionPane.showMessageDialog(null,"Planificacion "+formateador.format(date)+" se descargo con exito en su escritorio");
       } catch (FileNotFoundException ex) {
            Logger.getLogger(ModeloExcel.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null,"Cerrar archivo Excel para poder actualizar los datos");
        } catch (IOException ex) {
            Logger.getLogger(ModeloExcel.class.getName()).log(Level.SEVERE, null, ex);
            //JOptionPane.showMessageDialog(null,"hola 2");
        } 
        
       
   }
}
