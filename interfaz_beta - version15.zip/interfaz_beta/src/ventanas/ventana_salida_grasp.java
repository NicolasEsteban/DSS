/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;


import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import modelos.*;
import static ventanas.ventana_ejecucion_grasp.calcularHora;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

public class ventana_salida_grasp extends javax.swing.JDialog {

     boolean[] editable = {false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false,false};
    DefaultTableModel modelo = new DefaultTableModel(){
        public boolean isCellEditable(int row, int column){
                return editable[column];
        }
    
    };
    
    ArrayList<Predio> predios = new ArrayList();
    ArrayList<Bloque> bloques = new ArrayList();
    ArrayList<PredioSeleccionado> nombresPredios = new ArrayList();
    ArrayList<Integer> bloquesSeleccionados = new ArrayList();
    
    DefaultCategoryDataset dataset = new DefaultCategoryDataset();
    
    void agregar(ArrayList<Predio> listaPredioFinal, ArrayList<Bloque> listaBloqueFinal, ArrayList <PredioSeleccionado> listaSelec ){ // mostrar datos de los predios en una tabla
        
        String[] titulo = new String[26];
        titulo[0]="PREDIO";
        titulo[1]="TIEMPO DE INICIO DE COSECHA";
        for(int i=2;i<26;i++){
            titulo[i]="BLOQUE "+(i-1);
        }
        modelo.setColumnIdentifiers(titulo);
        tabla_salida.setModel(modelo);
        
        
        for(int i=0;i<listaPredioFinal.size();i++){
            //modelo.addRow(new Object[]{"Predio "+listaPredioFinal.get(i).getId()});
            Object fila[] = new Object[26];// se crea objeto para rellenar la tabla
            //fila[0]="Predio "+listaPredioFinal.get(i).getId();
            fila[0]=listaSelec.get(i).getNombre_predio();
            fila[1]=calcularHora(listaPredioFinal.get(i).y);
            int numeroBloque=0;
                       
            //for (Predio p : listaPredioFinal) {
                
                //System.out.println(listaPredioFinal.get(i).id);
                for (Carga c : listaPredioFinal.get(i).C) {
                    
                    //System.out.print(calcularHora(c.x));
                    //System.out.println("\n");
                    String[] parts = calcularHora(c.x).split(":");
                    String bloqueSeleccionado=parts[0]+":00:00"; // Se obtiene su tiempo de inicio
                    numeroBloque=buscarBloque(listaBloqueFinal,bloqueSeleccionado); // se busca el bloque al cual pertenece el tiempo
                    fila[numeroBloque+1]=calcularHora(c.x);
                    //System.out.println(bloquePerteneciente);
                    //System.out.println("\n");
                    if(bloquesSeleccionados.size()==0){
                        bloquesSeleccionados.add(numeroBloque);
                    }else{
                        int verificador=0;
                        for(int k=0;k<bloquesSeleccionados.size();k++){
                            if(bloquesSeleccionados.get(k)==numeroBloque){
                                verificador=1;
                            }
                        }
                        if(verificador==0){
                            bloquesSeleccionados.add(numeroBloque);
                        }
                    }
                    
                }
            //}
         
            
            modelo.addRow(fila);
        }
        tabla_salida.getColumn("PREDIO").setPreferredWidth(230);
        tabla_salida.getColumn("TIEMPO DE INICIO DE COSECHA").setPreferredWidth(170);
        
    }
    
    public ventana_salida_grasp(java.awt.Frame parent, boolean modal,ArrayList<Predio> listaPredioFinal,ArrayList <Bloque> listaBloqueFinal,ArrayList <PredioSeleccionado> listaSelec) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(null);
        tabla_salida.setAutoResizeMode(JTable.AUTO_RESIZE_OFF); // se desabilita e auto ajuste de las columnas
        
        predios.clear();
        bloques.clear();
        nombresPredios.clear();
        bloquesSeleccionados.clear();
        
        
        agregar(listaPredioFinal,listaBloqueFinal,listaSelec);
        
        for(int i=0;i<listaPredioFinal.size();i++){ // se traspasan los datos a la variable de estas ventana
            predios.add(listaPredioFinal.get(i));
            nombresPredios.add(listaSelec.get(i));
        }
        
        for(int i=0;i<listaBloqueFinal.size();i++){
            bloques.add(listaBloqueFinal.get(i));
        }
        // Se ordenan bloques seleccionados
        Collections.sort(bloquesSeleccionados);
        
        int frecuencia[]=frecuencia_camiones(predios,bloques,nombresPredios,bloquesSeleccionados);
        
        

        // graficas
        
        /*
        dataset.addValue(1.0, "Egresos", "Enero");
        dataset.addValue(3.0, "Egresos", "Febrero");
        dataset.addValue(2.0, "Egresos", "Marzo");
        
        dataset.addValue(2.0, "Ingresos", "Enero");
        dataset.addValue(3.0, "Ingresos", "Febrero");
        dataset.addValue(4.0, "Ingresos", "Marzo");*/
        
        for(int i=0;i<frecuencia.length;i++){
            dataset.addValue(frecuencia[i], "Bloques",bloquesSeleccionados.get(i));
            //dataset.addValue(frecuencia[i],new Color(0,0,64),bloquesSeleccionados.get(i));
        }
        
        JFreeChart chart = ChartFactory.createBarChart(
        "Grafica de barras", // El titulo de la gráfica
        "Bloques de horario", // Etiqueta de categoria
        "Frecuencia Camiones", // Etiqueta de valores
        dataset, // Datos
        PlotOrientation.VERTICAL, // orientacion
        true, // Incluye Leyenda
        true, // Incluye tooltips
        false // URLs?
        ); 
        
       
        //ChartFrame frame = new ChartFrame("Graficador", chart);
        ChartPanel panel = new ChartPanel(chart);
        
        panel_grafico.add(panel);
        panel_grafico.removeAll();
        panel_grafico.setLayout(new java.awt.BorderLayout());
        panel_grafico.add(panel);
        panel_grafico.validate();
        
        
        
        
    }
    
    public static int[] frecuencia_camiones(ArrayList<Predio> predios,ArrayList<Bloque> bloques,ArrayList<PredioSeleccionado> nombresPredios,ArrayList<Integer> bloquesSeleccionados){
        int frecuencia[]=new int[bloquesSeleccionados.size()];
        for(int i=0;i<frecuencia.length;i++){
            frecuencia[i]=0;
        }
        
        for(int i=0;i<predios.size();i++){
            
            int k=0;
                for (Carga c : predios.get(i).C) {
                    String[] parts = calcularHora(c.x).split(":");
                    String bloqueSeleccionado=parts[0]+":00:00"; // Se obtiene su tiempo de inicio
                    k=buscarBloque(bloques,bloqueSeleccionado); // se busca el bloque al cual pertenece el tiempo
                    int l=0;
                    while(l<bloquesSeleccionados.size()){
                        if(k==bloquesSeleccionados.get(l)){
                            frecuencia[l]=frecuencia[l]+1;
                            break;
                        }
                        l++;
                    }
                }
        
        
        }
        
        return frecuencia;
    }

    public static int buscarBloque(ArrayList<Bloque> listaBloque,String bloqueSeleccionado){
        int i=0;
        for (Bloque b : listaBloque) {
            i++;
            //System.out.println("Bloque "+i+": Tinicio->"+calcularHora(b.a)+" CapDesc->"+b.N+" CS->"+b.CS+" CF->"+b.CF);
            if(bloqueSeleccionado.equals(calcularHora(b.a))){
                //System.out.println(i);
                return i;
            }
        }
        return i;
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_salida = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        panel_grafico = new javax.swing.JPanel();
        panel_titulo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tabla_salida.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {},
                {},
                {},
                {},
                {},
                {},
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tabla_salida);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 990, 270));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Atras");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 640, 120, 40));

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setForeground(new java.awt.Color(0, 0, 0));
        jButton2.setText("Descargar Excel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 170, 170, 50));

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setForeground(new java.awt.Color(0, 0, 0));
        jButton3.setText("Descargar Pdf");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 240, 170, 50));
        getContentPane().add(panel_grafico, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 350, 990, 280));

        panel_titulo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("Resultado planificacion zona sur");
        panel_titulo.add(jLabel1);

        getContentPane().add(panel_titulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 40, 990, 40));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/nuevo-tomates.jpg"))); // NOI18N
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
        
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        ModeloExcel me = new ModeloExcel();
        me.salida_grasp(predios, bloques, nombresPredios);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        ModeloPdf mp = new ModeloPdf();
        mp.crearPdf(predios, bloques, nombresPredios,bloquesSeleccionados);
    }//GEN-LAST:event_jButton3ActionPerformed

    
    /**
     * @param args the command line arguments
     */


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panel_grafico;
    private javax.swing.JPanel panel_titulo;
    private javax.swing.JTable tabla_salida;
    // End of variables declaration//GEN-END:variables
}
