/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import jxl.format.Border;

import modelos.*;

public class Ventana_agregar_cargas extends javax.swing.JDialog {
    int posicion=0,Ncargas[],contador=0;
    ArrayList<PredioSeleccionado> listaSelec = new ArrayList();
    
    List<JTextField> campos = new ArrayList<>(); // para guardar contenido de los campos de textos
    
    public Ventana_agregar_cargas(java.awt.Frame parent, boolean modal,ArrayList<PredioSeleccionado> seleccionados) {
        super(parent, modal);
        initComponents();
        this.setLocationRelativeTo(null);
        
        
        
        Ncargas=new int[seleccionados.size()];
        contador= seleccionados.size();
        for(int i=0;i<seleccionados.size();i++){ // se pasan datos del arraylist al arraylist global
            listaSelec.add(seleccionados.get(i));
        }
        
        for(int i=0;i<seleccionados.size();i++){// se inicializa vector de cargas
            Ncargas[i]=-1;
        }
        
        panel.setBackground(Color.GRAY); // se le da el color gris al panel
        GridBagLayout gridBag = new GridBagLayout (); // se selecciona tipo de layout
        panel.setLayout(gridBag);
        GridBagConstraints restricciones = new GridBagConstraints ();
        
        
        
        for(int i=0;i<seleccionados.size();i++){
            
            
            
            restricciones.gridwidth = GridBagConstraints.RELATIVE; // label antepenultimo espacio
            restricciones.weightx = 1.5;
            JLabel label= new JLabel(seleccionados.get(i).getNombre_predio());
            gridBag.setConstraints (label, restricciones);      // se agrefa restriccion
            panel.add(label);                                   // se agrega a panel
            
            restricciones.gridwidth = GridBagConstraints.REMAINDER; // campo de texto, ultimo en la fila
            JTextField input = new JTextField(10);
            input.setHorizontalAlignment(JTextField.CENTER); 
            input.addKeyListener(new KeyAdapter(){ // se crea restriccion para evitar que se ingresen letras, 
                public void keyTyped(KeyEvent e)   // numeros flotantes, o negativos.
                {
                    char car= e.getKeyChar();
                    if((car<'0' || car>'9') && (car!=',' || car!='.' )) e.consume();
                    
        
                }
            });
            
            gridBag.setConstraints (input, restricciones);          // se agregan restricciones
            panel.add(input);
            campos.add(input); // se almacenan campos de texto en arrayList de campos de texto
        }
       
        // se desabilitan campos de textos
        /*jpredios.setEditable(false);
        jpredios.setText(seleccionados.get(posicion).getNombre_predio());
        
        
        jcargas.setHorizontalAlignment(JTextField.CENTER); 
        
        jcontador.setEditable(false);
        jcontador.setText(String.valueOf(seleccionados.size()));
        jcontador.setHorizontalAlignment(JTextField.CENTER); 
        */
        
        //PredioModel pm = new PredioModel();
        //pm.llamar_predio_seleccionado(seleccionados.get(posicion).getSuper_men(),seleccionados.get(posicion).getNombre_predio());
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        panel = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Ingresar cantidad de cargas por predio");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 250, 240, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo blanco.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 240, 500, 50));

        jButton1.setBackground(new java.awt.Color(255, 255, 255));
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Cancelar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 650, 90, 50));

        panel.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                panelKeyTyped(evt);
            }
        });
        jScrollPane1.setViewportView(panel);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 290, 370, 200));

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setForeground(new java.awt.Color(0, 0, 0));
        jButton2.setText("Ingresar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 310, -1, 40));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/fondo plomo.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 290, 130, 200));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/nuevo-tomates.jpg"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        /*int km_talca=0;
        ArrayList<Predio> entradaGrasp = new ArrayList();
        if(jcargas.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Ingresar valor en el campo de texto");
        }else{
            if(contador>1){
                
                Ncargas[posicion]=Integer.parseInt(jcargas.getText()); // se almacena carga en la posicion indicada
                posicion++; // se procede a mostrar el siguiente elemento
                jpredios.setText(listaSelec.get(posicion).getNombre_predio());
                
                
                contador--; // contador decrece y se muestra en la intefaz
                jcontador.setText(String.valueOf(contador));
                jcargas.setText("");// se limpia el campo de texto
                
            }else{
                
                Ncargas[posicion]=Integer.parseInt(jcargas.getText()); // se ingresa las cargas del ultimo predio
                
                JOptionPane.showMessageDialog(null,"Cargas ingresadas correctamente"); // mensjae 
                
                
                jcargas.setText("");
                jcargas.setEnabled(false);// se bloquea el campo de texto cuando termina de ocuparce
                
                PredioModel pm = new PredioModel();
                for(int i=0;i<listaSelec.size();i++){// se extrae la distancia del predio con respecto a talca
                    km_talca=pm.llamar_predio_seleccionado(listaSelec.get(i).getSuper_men(),listaSelec.get(i).getNombre_predio());
                    Predio pr;
                    float tiempo= (float)km_talca/50*60; // se multiplican por 60 para que se midan en minutos
                    float tiempoC = (float)10/Ncargas[i]*60;
                    
                    pr=new Predio(listaSelec.get(i).getLugar(),Ncargas[i],tiempoC,tiempo);
                    entradaGrasp.add(pr);
                }
                
                ventana_ejecucion_grasp dialog = new ventana_ejecucion_grasp(new javax.swing.JFrame(), true,entradaGrasp,listaSelec);// se llama ventana para ejecutar algoritmo
                dialog.setVisible(true);
                dispose(); // se cierra al cerrar la ventana siguiente
            }
            
            
        }*/
        
        ArrayList<Predio> entradaGrasp = new ArrayList();
        int km_talca=0,verificador=0;
        int j=0;
        
        for(JTextField txt: campos){// se verifican que no hayan campos vacios
            
            if(txt.getText().equals("")){
                verificador=1;
            
            }
            j++;
        }
        if(verificador==1){
            JOptionPane.showMessageDialog(null,"Se dejo un campo de texto vacio"); // mensajae 
           
        }else{           
            j=0;
            for(JTextField txt: campos){// se leen datos 
                //System.out.println(txt.getText());
                Ncargas[j]=Integer.parseInt(txt.getText()); // se almacenan cargas
                j++;
            }
        
            PredioModel pm = new PredioModel();
            for(int i=0;i<listaSelec.size();i++){// se extrae la distancia del predio con respecto a talca
                km_talca=pm.llamar_predio_seleccionado(listaSelec.get(i).getSuper_men(),listaSelec.get(i).getNombre_predio());
                Predio pr;
                float tiempo= (float)km_talca/50*60; // se multiplican por 60 para que se midan en minutos
                float tiempoC = (float)10/Ncargas[i]*60;
                pr=new Predio(listaSelec.get(i).getLugar(),Ncargas[i],tiempoC,tiempo);
                entradaGrasp.add(pr);
            }
            JOptionPane.showMessageDialog(null,"Cargas ingresadas correctamente"); // mensajae
            /*
            ventana_ejecucion_grasp dialog = new ventana_ejecucion_grasp(new javax.swing.JFrame(), true,entradaGrasp,listaSelec);// se llama ventana para ejecutar algoritmo
            dialog.setVisible(true);*/
            ventana_capacidad_descarga dialog = new ventana_capacidad_descarga(new javax.swing.JFrame(), true,entradaGrasp,listaSelec);
            dialog.setVisible(true);
            dispose();
            
        }
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void panelKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_panelKeyTyped
        char car= evt.getKeyChar();
        if((car<'0' || car>'9') && (car!=',' || car!='.')) evt.consume();
    }//GEN-LAST:event_panelKeyTyped

    
    /**
     * @param args the command line arguments
     */
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel panel;
    // End of variables declaration//GEN-END:variables
}
