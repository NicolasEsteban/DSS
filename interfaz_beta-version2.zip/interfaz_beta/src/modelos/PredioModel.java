package modelos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class PredioModel {
    public void insertar_predio(ArrayList<String> celdas,int aux){
        String sql = "INSERT INTO PREDIO (tecnico,productor,super_men,nombre_predio,comuna_predio,km_talca,productividad) VALUES(?,?,?,?,?,?,?)";
        
        Conexion con = new Conexion();
        PreparedStatement ps;
        Connection conn = con.getConexion();
        
        
        try { 
            ps = conn.prepareStatement(sql);
            ps.setString(1,celdas.get(0+aux));
            ps.setString(2,celdas.get(1+aux));
            ps.setString(3,celdas.get(2+aux));
            ps.setString(4,celdas.get(3+aux));
            ps.setString(5,celdas.get(4+aux));
            ps.setInt(6, Integer.parseInt(celdas.get(5+aux)));
            ps.setString(7,"");
            ps.execute();
            
        } catch (SQLException ex) {
            Logger.getLogger(PredioModel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public ArrayList llamar_predios(){ // funcion que llama la lista de predios en la vista de planificacion
        Conexion con = new Conexion();
        PreparedStatement ps;
        ResultSet rs;
        Connection conn = con.getConexion();
        ArrayList<String> Listapredios = new ArrayList();
        
        try {
            ps = conn.prepareStatement("SELECT nombre_predio FROM PREDIO");
            rs = ps.executeQuery();
            
            while (rs.next()){ // se guardan los datos en un arreglo de tipo objeto 
                Listapredios.add(rs.getString(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(PredioModel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return Listapredios;        
    }
}
