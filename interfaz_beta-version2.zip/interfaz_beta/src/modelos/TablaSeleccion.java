
package modelos;


import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class TablaSeleccion {
    
    private boolean[] editable = {false,true};
    ArrayList<String> Listapredios = new ArrayList();
    
    public void visualizar(JTable tabla){
        
        tabla.setDefaultRenderer(Object.class, new Render());
        DefaultTableModel dt= new DefaultTableModel(new String[]{"PREDIOS","ACCION"}, 0) {
 
            Class[] types = new Class[]{
                java.lang.Object.class,java.lang.Boolean.class
            };
 
            public Class getColumnClass(int columnIndex) {
                return types[columnIndex];
            }
            
            public boolean isCellEditable(int row, int column){
                return editable[column];
            }
        };
        
        
        //tabla.getColumn("PREDIOS").setPreferredWidth(300);
        PredioModel pm = new PredioModel();
        Listapredios = pm.llamar_predios();
        for(int i=0; i< Listapredios.size(); i++){
            Object fila[] = new Object[2];
            fila[0] = Listapredios.get(i);
            fila[1] = false;
            dt.addRow(fila);
        }
        
        
        
        tabla.setModel(dt);
        tabla.getColumn("PREDIOS").setPreferredWidth(300);
    
    }

    
    
}

