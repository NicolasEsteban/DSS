/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

import java.util.ArrayList;

import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import static ventanas.ventana_ejecucion_grasp.calcularHora;
//import static ventanas.ventana_salida_grasp.buscarBloque;








public class ModeloPdf {
    public void crearPdf(ArrayList<Predio> predios,ArrayList<Bloque> bloques,ArrayList<PredioSeleccionado> nombresPredios,ArrayList<Integer> bloquesSeleccionados){
        String ruta= System.getProperty("user.home") + "\\desktop"; 
        String Dest=ruta+"\\Reporte en PDF.pdf";
        
        Document document = new Document();
        
        try{
            PdfWriter.getInstance(document, new FileOutputStream(Dest));
            document.open();
            // Se crea tabla en pdf
            PdfPTable tablaTitulo = new PdfPTable(3);
            PdfPCell primeraCelda = new PdfPCell(new Paragraph(" "));
            primeraCelda.setColspan(1);
            primeraCelda.setRowspan(2);
            tablaTitulo.addCell(primeraCelda);
            // Se crea estilo en el parrafo
            Paragraph columna1 = new Paragraph("Reporte Sistema");
            columna1.getFont().setStyle(Font.BOLD);
            columna1.getFont().setSize(15);
            columna1.setAlignment(1);
            
            tablaTitulo.addCell(columna1);
            
            SimpleDateFormat formateador = new SimpleDateFormat("dd-MM-yyyy"); 
            Date date = new Date();
            //System.out.println(formateador.format(date));
            
            
            
            PdfPCell celdaFinal = new PdfPCell(new Paragraph(formateador.format(date)));
            celdaFinal.setColspan(1);
            celdaFinal.setRowspan(2);
            
            tablaTitulo.addCell(celdaFinal);
            // Estilos
            Paragraph columna2 = new Paragraph("Sistema de Planificacion de Cosecha");
            columna2.getFont().setStyle(Font.BOLD);
            columna2.getFont().setSize(15);
            columna2.setAlignment(1);
            
            tablaTitulo.addCell(columna2);
            tablaTitulo.setWidthPercentage(100);
            // Se agrega tabla
            document.add(tablaTitulo);
            
            document.add(new Paragraph("\n\n"));
            
            
            // se creara tabla con los datos
            PdfPTable tablaDatos = new PdfPTable(bloquesSeleccionados.size()+2);
            
            Paragraph columnaDatos = new Paragraph("PREDIOS");
            columnaDatos.getFont().setStyle(Font.BOLD);
            columnaDatos.getFont().setSize(8);
            
            tablaDatos.addCell(columnaDatos);
            columnaDatos=new Paragraph("TCOSECHA");
            columnaDatos.getFont().setStyle(Font.BOLD);
            columnaDatos.getFont().setSize(8);
            tablaDatos.addCell(columnaDatos);
            for(int i=0;i<bloquesSeleccionados.size();i++){
                columnaDatos=new Paragraph("BLOQUE "+bloquesSeleccionados.get(i));
                columnaDatos.getFont().setStyle(Font.BOLD);
                columnaDatos.getFont().setSize(8);
                tablaDatos.addCell(columnaDatos);
            }
            
            String[] arreglo= new String[bloquesSeleccionados.size()];
            
            for(int i=0;i<predios.size();i++){
                columnaDatos=new Paragraph(nombresPredios.get(i).getNombre_predio());
                columnaDatos.getFont().setSize(6);
                columnaDatos.getFont().setStyle(Font.BOLD);
                tablaDatos.addCell(columnaDatos);
                
                columnaDatos=new Paragraph(calcularHora(predios.get(i).y));
                columnaDatos.getFont().setSize(6);
                columnaDatos.getFont().setStyle(Font.BOLD);
                tablaDatos.addCell(columnaDatos);
                
                int numeroBloque=0;
                
                for(int j=0;j<bloquesSeleccionados.size();j++){
                    arreglo[j]=" ";
                }
                int k=0;
                for (Carga c : predios.get(i).C) {
                    
                    //System.out.print(calcularHora(c.x));
                    //System.out.println("\n");
                    String[] parts = calcularHora(c.x).split(":");
                    String bloqueSeleccionado=parts[0]+":00:00"; // Se obtiene su tiempo de inicio
                    //numeroBloque=buscarBloque(bloques,bloqueSeleccionado); // se busca el bloque al cual pertenece el tiempo
                    //arreglo[k]=calcularHora(c.x);
                    //k++;
                    int l=0;
                    while(l<bloquesSeleccionados.size()){
                        if(numeroBloque==bloquesSeleccionados.get(l)){
                            arreglo[l]=calcularHora(c.x);
                            break;
                        }
                        l++;
                    }
                    
                }
                
                
                /*for(int j=0;j<bloquesSeleccionados.size();j++){
                    System.out.println(arreglo[j]);
                }*/
                //System.out.println("\n");
                for(int j=0;j<bloquesSeleccionados.size();j++){
                    columnaDatos=new Paragraph(arreglo[j]);
                    columnaDatos.getFont().setSize(6);
                    columnaDatos.getFont().setStyle(Font.BOLD);
                    tablaDatos.addCell(columnaDatos);
                    //tablaDatos.addCell("hola");
                }
                
            }
            
            tablaDatos.setWidthPercentage(100);
            document.add(tablaDatos);
            Paragraph columnaObs = new Paragraph("Observaciones: \n\n");
            columnaObs.getFont().setStyle(Font.BOLD);
            //columnaObs.getFont().setSize(18);
            
            
            document.add(new Paragraph("\n\n"));
            document.add(columnaObs);
            PdfPTable tablaObservacion = new PdfPTable(8);
            
            PdfPCell celdaObservacion = new PdfPCell(new Paragraph("\n\n\n\n\n\n\n\n"));
            celdaObservacion.setColspan(8);
            //celdaObservacion.setRowspan(1);
            tablaObservacion.addCell(celdaObservacion);
            document.add(tablaObservacion);
            document.close();
            JOptionPane.showMessageDialog(null,"Pdf creado correctamente");
        }catch(Exception e)
        {
            //System.err.println("Ocurrio un error al crear el archivo");
            JOptionPane.showMessageDialog(null,"Ocurrio un error al crear el archivo");
        }
        
              
    }
}
